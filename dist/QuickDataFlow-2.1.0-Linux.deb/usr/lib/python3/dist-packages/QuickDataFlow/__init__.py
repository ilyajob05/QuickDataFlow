# __init__.py
__import__("pkg_resources").declare_namespace(__name__)
from .shm_message import MessageBuff
